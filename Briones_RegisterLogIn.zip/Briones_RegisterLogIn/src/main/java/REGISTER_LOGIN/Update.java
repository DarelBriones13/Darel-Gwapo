/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package REGISTER_LOGIN;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import javax.swing.*;

public class Update extends javax.swing.JFrame {
    private String emailOrNum;
    
    public Update() {
        initComponents();
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        updateFname = new javax.swing.JTextField();
        updateLname = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        updateMale = new javax.swing.JRadioButton();
        jLabel3 = new javax.swing.JLabel();
        updateFemale = new javax.swing.JRadioButton();
        updateGay = new javax.swing.JRadioButton();
        updateEat = new javax.swing.JCheckBox();
        updateRead = new javax.swing.JCheckBox();
        updatePlay = new javax.swing.JCheckBox();
        updateExercise = new javax.swing.JCheckBox();
        updateStudy = new javax.swing.JCheckBox();
        jLabel4 = new javax.swing.JLabel();
        btnYes = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        btnNo = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();
        btnUpdated = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("UPDATE");

        jPanel1.setPreferredSize(new java.awt.Dimension(500, 600));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 30)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 255));
        jLabel1.setText("UPDATE INFORMATION");

        updateFname.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        updateFname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateFnameActionPerformed(evt);
            }
        });

        updateLname.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        updateLname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateLnameActionPerformed(evt);
            }
        });

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "BSIT", "BSOA", "BSBA", "BSCRIM", "BSEDUC" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setText("GENDER:");

        buttonGroup1.add(updateMale);
        updateMale.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        updateMale.setText("MALE");
        updateMale.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateMaleActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("HOBBIES:");

        buttonGroup1.add(updateFemale);
        updateFemale.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        updateFemale.setText("FEMALE");
        updateFemale.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateFemaleActionPerformed(evt);
            }
        });

        buttonGroup1.add(updateGay);
        updateGay.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        updateGay.setText("GAY");
        updateGay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateGayActionPerformed(evt);
            }
        });

        updateEat.setText("Eating");
        updateEat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateEatActionPerformed(evt);
            }
        });

        updateRead.setText("Reading");
        updateRead.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateReadActionPerformed(evt);
            }
        });

        updatePlay.setText("Playing online games");
        updatePlay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatePlayActionPerformed(evt);
            }
        });

        updateExercise.setText("Exercising");
        updateExercise.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateExerciseActionPerformed(evt);
            }
        });

        updateStudy.setText("Studying");
        updateStudy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateStudyActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Do you also want to update your password?");

        btnYes.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnYes.setForeground(new java.awt.Color(0, 0, 255));
        btnYes.setText("Yes");
        btnYes.setBorder(null);
        btnYes.setBorderPainted(false);
        btnYes.setContentAreaFilled(false);
        btnYes.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnYes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnYesActionPerformed(evt);
            }
        });

        jLabel5.setText("/");

        btnNo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnNo.setForeground(new java.awt.Color(255, 0, 0));
        btnNo.setText("No");
        btnNo.setBorder(null);
        btnNo.setBorderPainted(false);
        btnNo.setContentAreaFilled(false);
        btnNo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNoActionPerformed(evt);
            }
        });

        btnCancel.setBackground(new java.awt.Color(255, 0, 0));
        btnCancel.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnCancel.setForeground(new java.awt.Color(255, 255, 255));
        btnCancel.setText("Cancel");
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });

        btnUpdated.setBackground(new java.awt.Color(0, 204, 0));
        btnUpdated.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnUpdated.setForeground(new java.awt.Color(255, 255, 255));
        btnUpdated.setText("Update");
        btnUpdated.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdatedActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(updateFname, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2)
                            .addComponent(updateMale)
                            .addComponent(updateFemale)
                            .addComponent(updateGay))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(updateLname, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(updateEat)
                                .addGap(27, 27, 27)
                                .addComponent(updateExercise))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(updateRead)
                                .addGap(18, 18, 18)
                                .addComponent(updateStudy))
                            .addComponent(updatePlay)
                            .addComponent(jLabel3)))
                    .addComponent(jComboBox1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnYes)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnNo))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(btnCancel, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(45, 45, 45)
                        .addComponent(btnUpdated, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(113, 113, 113)))
                .addContainerGap(28, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(updateFname, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(updateLname, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(updateMale)
                    .addComponent(updateEat)
                    .addComponent(updateExercise))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(updateFemale)
                    .addComponent(updateRead)
                    .addComponent(updateStudy))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(updateGay)
                    .addComponent(updatePlay))
                .addGap(36, 36, 36)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(117, 117, 117)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(btnYes)
                    .addComponent(jLabel5)
                    .addComponent(btnNo))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 53, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnUpdated)
                    .addComponent(btnCancel))
                .addGap(50, 50, 50))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void updateFnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateFnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_updateFnameActionPerformed

    private void updateLnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateLnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_updateLnameActionPerformed

    private void updateMaleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateMaleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_updateMaleActionPerformed

    private void updateFemaleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateFemaleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_updateFemaleActionPerformed

    private void updateGayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateGayActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_updateGayActionPerformed

    private void updateEatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateEatActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_updateEatActionPerformed

    private void updateReadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateReadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_updateReadActionPerformed

    private void updatePlayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatePlayActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_updatePlayActionPerformed

    private void updateExerciseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateExerciseActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_updateExerciseActionPerformed

    private void updateStudyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateStudyActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_updateStudyActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed
    public void displayUserInfo(String emailOrNum) {
        emailOrNum = emailOrNum.replaceAll("[^a-zA-Z0-9]", "_");
        String filePath = "C:\\Users\\Darel Briones\\Downloads\\UPDATED FACEBOOK\\UPDATED FACEBOOK\\Briones_RegisterLogIn\\" + emailOrNum + ".txt";
        Path path = Paths.get(filePath);

        if (Files.exists(path)) {
            try {
                List<String> lines = Files.readAllLines(path);
                String[] nameParts = lines.get(0).split(" ");
                if (nameParts.length >= 2) {
                    updateFname.setText(nameParts[0]); 
                    updateLname.setText(nameParts[1]); 
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    private void btnYesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnYesActionPerformed
        JPasswordField pf = new JPasswordField();
    int confirm = JOptionPane.showConfirmDialog(null, pf, "Enter new password:", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

    if (confirm == JOptionPane.OK_OPTION) {
        char[] password = pf.getPassword();
        String newPassword = new String(password);

        JPasswordField pfConfirm = new JPasswordField();
        int confirmPass = JOptionPane.showConfirmDialog(null, pfConfirm, "Confirm new password:", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (confirmPass == JOptionPane.OK_OPTION) {
            char[] confirmPassword = pfConfirm.getPassword();
            String confirmedPassword = new String(confirmPassword);

            if (newPassword.equals(confirmedPassword)) {
                String filePath = "C:\\Users\\Darel Briones\\Downloads\\Facebook-Account-main\\Briones_RegisterLogIn\\" + emailOrNum + ".txt";
                Path path = Paths.get(filePath);

                if (Files.exists(path)) {
                    try {
                        List<String> fileContent = new ArrayList<>(Files.readAllLines(path));
                        fileContent.set(2, "Password: " + confirmedPassword);
                        Files.write(path, fileContent);
                        JOptionPane.showMessageDialog(this, "Password updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    } catch (IOException e) {
                        e.printStackTrace();
                        JOptionPane.showMessageDialog(this, "Error occurred while updating password!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "Passwords do not match!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    }//GEN-LAST:event_btnYesActionPerformed

    private void btnNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnNoActionPerformed

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnCancelActionPerformed
    private String getSelectedGender() {
    if (updateMale.isSelected()) {
        return updateMale.getText();
    } else if (updateFemale.isSelected()) {
        return updateFemale.getText();
    } else if (updateGay.isSelected()) {
        return updateGay.getText();
    } else {
        return null;
    }
    }
    private ArrayList<String> getSelectedHobbies() {
    ArrayList<String> selectedHobbies = new ArrayList<>();
    if (updateExercise.isSelected()) {
        selectedHobbies.add(updateExercise.getText());
    }
    if (updateRead.isSelected()) {
        selectedHobbies.add(updateRead.getText());
    }
    if (updateEat.isSelected()) {
        selectedHobbies.add(updateEat.getText());
    }
    if (updateStudy.isSelected()) {
        selectedHobbies.add(updateStudy.getText());
    }
    if (updatePlay.isSelected()) {
        selectedHobbies.add(updatePlay.getText());
    }
    return selectedHobbies;
    }
    private void btnUpdatedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdatedActionPerformed
        String firstName = updateFname.getText().trim();
        String lastName = updateLname.getText().trim();
        String selectedGender = getSelectedGender();
        String selectedCourse = (String) jComboBox1.getSelectedItem();
        ArrayList<String> selectedHobbies = getSelectedHobbies();

        // Validate if required fields are not empty
        if (firstName.isEmpty() || lastName.isEmpty() || selectedGender == null || selectedHobbies.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all required fields!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String filePath = "C:\\Users\\Darel Briones\\Downloads\\Facebook-Account-main\\Briones_RegisterLogIn\\" + emailOrNum + ".txt";
        Path path = Paths.get(filePath);

        if (Files.exists(path)) {
            try {
                List<String> fileContent = new ArrayList<>(Files.readAllLines(path));
                fileContent.set(0, "Name: " + firstName + " " + lastName);
                fileContent.set(3, "Gender: " + selectedGender);
                fileContent.set(4, "Course: " + selectedCourse);

                // Update hobbies (if exists in the file)
                for (int i = 0; i < selectedHobbies.size(); i++) {
                    if (fileContent.size() > i + 5) {
                        fileContent.set(i + 5, selectedHobbies.get(i));
                    } else {
                        fileContent.add("HOBBY: " + selectedHobbies.get(i));
                    }
                }

                Files.write(path, fileContent);
                JOptionPane.showMessageDialog(this, "Information updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error occurred while updating information!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_btnUpdatedActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Update.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Update.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Update.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Update.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Update().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnNo;
    private javax.swing.JButton btnUpdated;
    private javax.swing.JButton btnYes;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JCheckBox updateEat;
    private javax.swing.JCheckBox updateExercise;
    private javax.swing.JRadioButton updateFemale;
    private javax.swing.JTextField updateFname;
    private javax.swing.JRadioButton updateGay;
    private javax.swing.JTextField updateLname;
    private javax.swing.JRadioButton updateMale;
    private javax.swing.JCheckBox updatePlay;
    private javax.swing.JCheckBox updateRead;
    private javax.swing.JCheckBox updateStudy;
    // End of variables declaration//GEN-END:variables
}
